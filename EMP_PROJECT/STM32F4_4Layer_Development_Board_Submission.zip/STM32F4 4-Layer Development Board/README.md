# STM32F4 4-Layer Development Board

**Project:** STM32F405RGT6 4-Layer Development Board (`STM32F4_REV2`)
**Course:** Electronics Manufacturing & PCB Design (EMP)
**Date:** 8 November 2026

## Team

- Divyansh Rawat — Roll No. 124EC0030
- Rehan Afroz — Roll No. 124EC0033
- Ishan Pandey — Roll No. 124EC0032
- Dasari E S T Vishnu Vardhan — Roll No. 124EC0010

## Attribution & provenance

This hardware design is adapted and re-routed from the open-source STM32F4 Reference Design by Philip Salmony (Phil's Lab), used under the MIT License. The original copyright and license terms are preserved in full in [LICENSE](LICENSE). Stale original-author outputs (old assembly files, legacy formats) are excluded from this package; nothing was deleted from the source repository.

## Key specifications

- **Microcontroller:** STMicroelectronics STM32F405RGT6 (Arm Cortex-M4, 168 MHz, FPU, 1 MB Flash, 192 KB SRAM, LQFP-64)
- **Stackup:** 4 layers — F.Cu signal / In1.Cu solid GND / In2.Cu solid +3.3V / B.Cu signal (copper pours on the two inner layers only)
- **Power:** dual input — external DC screw terminal (J1, +12 V rail) or USB 5 V (J5, Micro-B) — regulated to +3.3 V by an MPS MP2359 1.4 MHz buck converter, with a filtered +3.3VA analog rail
- **USB:** USB 2.0 Full-Speed device port (Micro-B) with ST USBLC6-2SC6 ESD protection (U2)
- **Clock:** 16.000 MHz crystal (Y1) with 12 pF load capacitors (C11, C12), sized per ST AN2867
- **Debug:** 10-pin 1.27 mm SWD header (J2) with SWDIO, SWCLK, SWO and NRST
- **User I/O:** status LED (D1, blue, PA1), power LED (D4, red), I2C1 / USART3 headers (J3, J4)

## Package manifest

- [STM32F4_REV2.kicad_sch](STM32F4_REV2.kicad_sch), [STM32F4_REV2.kicad_pcb](STM32F4_REV2.kicad_pcb), [STM32F4_REV2.kicad_pro](STM32F4_REV2.kicad_pro), [STM32F4_REV2.kicad_sym](STM32F4_REV2.kicad_sym) — native KiCad 9 sources
- [lib/](lib/) — 3D STEP models used by the layout
- [manufacturing/](manufacturing/) — `STM32F4_REV2_gerbers.zip` (4-layer Gerbers + drill), `STM32F4_REV2_bom.csv`, `STM32F4_REV2_pos.csv`, `STM32F4_REV2_schematic.pdf`, `STM32F4_REV2.pdf` (layout plot), `STM32F4_REV2_3d.png`, `ibom.html`
- [verification/](verification/) — `erc-rerun.json`, `drc-rerun.json`, `gerbers-check/` (re-exported Gerber set)
- [DESIGN_CONSIDERATIONS.md](DESIGN_CONSIDERATIONS.md) (+ .docx) — engineering analysis and design calculations
- [EMP_STM32F4_4Layer_Presentation.pptx](EMP_STM32F4_4Layer_Presentation.pptx) — project presentation (editable)
- [PRESENTATION.md](PRESENTATION.md) — text outline of the presentation
- [LICENSE](LICENSE) — MIT, with Philip Salmony's attribution

## Verification summary

Design-file checks re-run by the team on 8 Nov 2026, 01:55 IST, KiCad 9.0.8 (reports in `verification/`): ERC 0 violations, DRC 0 violations, 0 unconnected items, schematic–PCB parity clean; BOM reconciled against position data (46 SMD parts match, mounting holes H1–H4 excluded by design); the re-exported Gerber set is identical to the submitted `gerbers.zip`.

These are software checks of the design files, re-run by the team (reports in `verification/`). No hardware was fabricated or tested.

## Review notes

- The KiCad title blocks in this package's sources carry the corrected team assignment (Divyansh Rawat = 124EC0030, Rehan Afroz = 124EC0033, Ishan Pandey = 124EC0032, Dasari E S T Vishnu Vardhan = 124EC0010), and the manufacturing PDF plots have been re-exported with the corrected title block.
- This package is a draft for review. It has not been committed to the repository or uploaded anywhere.
