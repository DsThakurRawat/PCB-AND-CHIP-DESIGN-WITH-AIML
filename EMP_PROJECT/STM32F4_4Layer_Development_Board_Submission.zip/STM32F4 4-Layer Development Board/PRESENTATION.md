# Presentation outline: STM32F4 4-Layer Development Board

Editable deck: `EMP_STM32F4_4Layer_Presentation.pptx` (12 slides). Text outline below.

**Course:** Electronics Manufacturing & PCB Design (EMP) · **Presentation:** 13 Nov 2026, 2:00 PM · **Duration:** 30 minutes (about 10 minutes per presenter, 4 slides each)

**Team:** Divyansh Rawat (124EC0030) · Rehan Afroz (124EC0032) · Ishan Pandey (124EC0033)
**Attribution:** adapted and re-routed from the Phil's Lab STM32F4 Reference Design by Philip Salmony (MIT License).

## Presenter 1 — Divyansh Rawat (slides 1–4): introduction and design

1. **Title** — project name, team, attribution, 3D render of the current design.
2. **What the board is** — STM32F405RGT6 core (168 MHz Cortex-M4, 1 MB Flash), 16 MHz crystal per AN2867, 10-pin SWD with NRST/SWO, 4-layer stackup, dual power input (screw terminal +12 V / USB Micro-B 5 V), MP2359 buck to +3.3 V, USB FS with ESD protection.
3. **System architecture** — both inputs through protection (D3, Q1, F1, FB1) into the MP2359 buck and the +3.3 V plane; MCU connected to USB (via U2 ESD array), SWD header, I2C/UART headers, LEDs, boot switch and crystal.
4. **Power subsystem** — dual protected inputs, filtering, MP2359 buck design and +3.3 V / +3.3VA distribution, with the key power-stage components.

## Presenter 2 — Rehan Afroz (slides 5–8): schematic and layout

5. **Schematic** — the actual KiCad plot from the current repository.
6. **Working views in KiCad 9** — the team's own session screenshots: Schematic Editor full sheet, and PCB Editor routed board (status bar shows Unrouted: 0).
7. **PCB layout** — two authentic views of the current design: top copper (F.Cu) tracks and pads rendered from the actual manufacturing Gerber (STM32F4_REV2-F_Cu.gtl) with the board outline, and the all-layers-overlaid KiCad PCBNEW plot (manufacturing/STM32F4_REV2.pdf).
8. **4-layer stackup & layout strategy** — F.Cu / solid GND / solid +3.3 V / B.Cu; layout design intent: decoupling per VDD pin, datasheet VCAP capacitors, buck hot loop kept compact, USB pair routed over the ground plane.

## Presenter 3 — Ishan Pandey (slides 9–12): manufacturing data and verification

9. **Exported design data** — Gerber Viewer with the Layers Manager listing all four copper layers, and the schematic sheet as plotted from KiCad (team's session screenshots).
10. **16 MHz oscillator design (ST AN2867)** — crystal and load-capacitor sizing; gain margin ≈ 20× against the STM32F4 HSE gm(min) of 5 mA/V (AN2867 Table 6), with the stated inputs.
11. **Verification** — ERC 0, DRC 0, 0 unconnected, parity clean, BOM/position data reconciled, Gerber re-export identical (re-run by the team, 8 Nov 2026, KiCad 9.0.8; reports under verification/). Software checks of the design files; no hardware was fabricated or tested.
12. **Submission package** — package contents and MIT provenance; draft for review.
