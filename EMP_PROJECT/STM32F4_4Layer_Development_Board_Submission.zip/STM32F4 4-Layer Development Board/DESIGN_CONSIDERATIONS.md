# STM32F4 4-Layer Development Board — Design Considerations

**Project:** STM32F4 4-Layer Development Board (`STM32F4_REV2`)
**Course:** Electronics Manufacturing & PCB Design (EMP)
**Date:** 8 November 2026

**Team**

- Divyansh Rawat — Roll No. 124EC0030
- Rehan Afroz — Roll No. 124EC0033
- Ishan Pandey — Roll No. 124EC0032

**Attribution:** Adapted and re-routed from the open-source STM32F4 Reference Design by Philip Salmony (Phil's Lab), used under the MIT License. The original copyright and license text are preserved with the design.

---

## 1. Scope and verification status

This document records the engineering reasoning behind the design and how the design files were verified.

All software design-file checks were re-run by the team on **8 Nov 2026, 01:55 IST, KiCad 9.0.8** (reports committed under `verification/`):

| Check | Command / method | Result |
| --- | --- | --- |
| Schematic ERC | `kicad-cli sch erc --severity-all` | 0 errors, 0 warnings, 0 violations |
| Board DRC | `kicad-cli pcb drc --severity-all` | 0 violations |
| Unconnected items | same DRC run | 0 |
| Schematic–PCB parity | `kicad-cli pcb drc --schematic-parity` | 0 discrepancies |
| BOM vs position data | `bom.csv` reconciled against `pos.csv` | 46 SMD parts match; mounting holes H1–H4 excluded by design; no DNP, no value mismatches |
| Gerber re-export | `kicad-cli pcb export gerbers` + `export drill` | 34-file set identical to the submitted `manufacturing/gerbers.zip` |

> **Verification boundary.** Passing ERC/DRC confirms the schematic connectivity and copper geometry are consistent and conform to the checked fabrication rules. These are software checks of the design files; no hardware was fabricated or tested.

## 2. Power subsystem

- **External DC input (J1, screw terminal):** feeds a +12 V input rail. Reverse-polarity protection by Schottky diode (B5819W).
- **USB input (J5, USB Micro-B, 5 V):** protected by Schottky diode (B5819W), 250 mA polyfuse (F1) and a 600 Ω @ 600 MHz ferrite bead (FB1). D2/D3 prevent back-feeding between the two sources.
- **Buck regulator:** MPS MP2359 (1.2 A, 1.4 MHz, specified input range 4.5–24 V) steps the input down to +3.3 V. Inductor L2 = 10 µH. Input tank C13 = 10 µF on BUCK_IN; rail capacitance on +3.3 V: C3 = 4.7 µF and C15/C17 = 10 µF, plus a 100 nF bypass capacitor at every VDD pin. The MCU's VCAP pins (31 and 47) carry the datasheet-required 2.2 µF each (C2, C1).
- **Distribution:** +3.3 V pours on inner layer In2.Cu; a filtered +3.3VA rail (L1, C9, C10) feeds the analog (ADC) supply domain.
- **Debug:** 10-pin 1.27 mm SWD header (J2) carrying SWDIO, SWCLK, SWO and NRST — the MCU reset line is reachable on pin 10; there is no separate reset pushbutton. Status LED D1 (blue) sits on PA1 (net LED_STATUS); D4 (red) is the power LED.

## 3. 16 MHz HSE oscillator (ST AN2867 method)

- Crystal Y1: 16.000 MHz, specified load capacitance C_L = 9 pF (JLCPCB C13738), ESR ≤ 50 Ω.
- Board load capacitors C11 = C12 = 12 pF → series combination 6 pF; matching C_L = 9 pF requires ≈ 3 pF of stray capacitance, a plausible value for a compact layout over a ground plane (AN2867 estimates 2–3 pF typical).
- Gain margin (AN2867): g_mcrit = 4 · ESR · (2πf)² · (C0 + C_L)². With ESR = 50 Ω, f = 16 MHz, C_L = 9 pF and an assumed C0 = 2 pF, g_mcrit ≈ 0.25 mA/V. Per AN2867 Table 6, the STM32F4 HSE oscillator's minimum transconductance is 5 mA/V, giving a margin of roughly **20×** — above the AN2867 minimum of 5×. (Equivalently, g_mcrit 0.25 mA/V < Gm_crit_max 1 mA/V.)

Reference: ST AN2867, *Oscillator design guide for STM32 MCUs* (st.com/resource/en/application_note/an2867).

## 4. Layout and signal integrity

Stackup: F.Cu (components + high-speed signals) / In1.Cu (solid GND pour) / In2.Cu (solid +3.3 V pour) / B.Cu (remaining signals, no copper pour). Copper pours exist only on the two inner layers.

Layout design intent:

- Every VDD pin has a 100 nF bypass capacitor placed adjacent to the pin; VDDA has a dedicated filter network.
- Top-layer high-speed traces are routed over the solid L2 ground plane as their intended return reference.
- Buck switch node, catch diode and inductor are grouped tightly, intending a small 1.4 MHz switching loop.
- USB D+/D− are routed as a short, side-by-side pair over the ground plane, protected by the USBLC6-2SC6 ESD array (U2) at the connector.

## 5. Package contents

Native KiCad 9 sources (`STM32F4_REV2.kicad_sch/.kicad_pcb/.kicad_pro`), `manufacturing/` (gerbers.zip with drill, bom.csv, pos.csv, schematic and layout PDFs, 3D render, interactive BOM), `verification/` (re-run ERC/DRC reports, re-exported gerber set), this document, the project presentation, and the MIT LICENSE file. Stale original-author outputs (old assembly files, legacy formats) are excluded from the package; nothing was deleted from the repository.

*Draft for review: the title-block roll-number correction (Divyansh Rawat = 124EC0030) is applied in this package's KiCad sources; the manufacturing PDF plots still show the pre-correction title block until re-exported from KiCad.*

---

*Software checks of the design files completed 8 Nov 2026 (KiCad 9.0.8). No hardware was fabricated or tested.*
