%TF.GenerationSoftware,KiCad,Pcbnew,9.0.8+dfsg-1*%
%TF.CreationDate,2026-11-05T00:42:56+05:30*%
%TF.ProjectId,demo_board_routed,64656d6f-5f62-46f6-9172-645f726f7574,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8+dfsg-1) date 2026-11-05 00:42:56*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
